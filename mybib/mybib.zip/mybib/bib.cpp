#include"bib.hpp"
using namespace std;
//constructor&destructor part
/*Name_class*/ Bib::Bib(/* args */)
{
    vector<int>::iterator it;
    for(it=x.begin();it!=x.end();++it)
    {
        (*it)=0;
    }
}
Bib::Bib(int x)
{
    vector<int>::iterator it;
    for (it = this->x.begin(); it != this->x.end(); ++it)
    {
        (*it)=x;
    }
}
/*Name_class*/ Bib::~Bib()
{
}
//method part :
void Bib::ajouter()
{
    vector<int>::iterator it;
        int val;
    cout<<"donner une valeur ";
    cin>>val;
    
    if (x.begin()==x.end())
    {
        x.push_back(val);
        cout << val << " ajouter avec succe" << endl;
    }
    else
    {
        for (it = x.begin(); it != x.end(); ++it)
        {
            if (val != (*it))
            {
                x.push_back(val);
                cout << val << " ajouter avec succe" << endl; 
            }
            else
                cout << "valeur exist deja !" << endl;
        }
    }
}
/*
add an element in a list in my case we need to switch the X type to liste<int> in hpp file
void Bib::ajouter()
{
    list<int>::iterator it;
        int val;
    cout<<"donner une valeur ";
    cin>>val;
    
    if (x.begin()==x.end())
    {
        x.push_back(val);
        cout << val << " ajouter avec succe" << endl;
    }
    else
    {
        for (it = x.begin(); it != x.end(); ++it)
        {
            if (val != (*it))
            {
                x.push_back(val);
                cout << val << " ajouter avec succe" << endl; 
            }
            else
                cout << "valeur exist deja !" << endl;
        }
    }
}
*/
void Bib::afficher()
{
    vector<int>::iterator it;
    cout<<"info : "<<endl;
    cout<<endl;
    for (it = x.begin(); it != x.end(); ++it)
    {
        cout<<"tab info :"<<endl<<(*it)<<endl;
    }
}
vector<int>::iterator Bib::rechercher(int val)
{
    vector<int>::iterator it;
    cout<<"donner la valeur a chercher : ";
    cin>>val;
    for (it=x.begin();it!=x.end();++it)
    {
        if((*it)==val)
            return it;
    }
    return x.end();
}
/*
search for element in a list in my case we need to switch the X type to liste<int> in hpp file
list<int>::iterator Bib::rechercher(int val)
{
    list<int>::iterator it;
    cout << "donner la valeur a chercher : ";
    cin >> val;
    for (it = x.begin(); it != x.end(); ++it)
    {
        if ((*it) == val)
            return it;
    }
    return x.end();
}*/
void Bib::supprimer()
{
    int val;
    
    vector<int>::iterator sup;
    vector<int>::iterator it;

        sup = rechercher(val);
        for(it=x.begin();it!=x.end();++it)
        {
            if(it==sup)
            {
                x.erase(sup);
                cout<<"suppression avec succe!"<<endl;
            }
            else
                cout<<"element non trouver"<<endl;
        }
}

/*
to delet an element from a list use the methode "chercher()" like i did 
    you need to change the type of SUP to list<you_variable_type> sup and list<you_variable_type> it and ofcourse the x need to be a list
void Bib::supprimer()
{
    int val;
    vector<int>::iterator sup;
    vector<int>::iterator it;

        sup = rechercher(val);
        for(it=x.begin();it!=x.end();++it)
        {
            if(it==sup)
            {
                x.erase(sup);
                cout<<"suppression avec succe!"<<endl;
            }
            else
                cout<<"element non trouver"<<endl;
        }
}
*/